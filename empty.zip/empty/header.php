<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();
?>
<!DOCTYPE html>
<html>
	<head>
		
		<?$APPLICATION->ShowHead();?>
		<title><?$APPLICATION->ShowTitle();?></title>
		<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" /> 	
  <!--<link rel="stylesheet" href="<?=SITE_TEMPLATE_PATH?>/dist/css/style.css" />-->
	</head>
	<body>
		<div id="panel">
			<?$APPLICATION->ShowPanel();?>
		</div>
		<div id="layout-main-wrap">
    <header class="layout">
    </header>
    <main id="page-home">
      <div class="device">
        <div class="device-popup"><div class="device-popup-icon"></div></div>
        <div class="device-pager"><ul>
          </ul></div>
        <div class="device-display">
        <div class="device-screens">
            </div>
          </div>
        <div class="device-menu">

        </div>
      </div>
    </main>
  </div>
  
						