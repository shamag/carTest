<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();
?>
 <script src="<?=SITE_TEMPLATE_PATH?>/js/app.js"></script>
	</body>
</html>